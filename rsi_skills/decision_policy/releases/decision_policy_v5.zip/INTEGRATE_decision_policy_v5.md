# Decision Policy RSI Skill v5（5.0.0）：v4 + 种群式搜索（evolve.parents、evolve.continuous）

来源：https://github.com/Jireh-Chen/DM-RSI-Framework 的 `rsi_skills/decision_policy/`。各版本的区别和实验结果见那里的 `VERSIONS.md`。

## 前提

你的仓库里已经有 onejev-harness 和 Elliptic++ benchmark（crypto-fraud-detection），并能用 harness 训练出 checkpoint。

## 集成（3 步）

1. 在你的仓库根目录解压这个 zip，文件会落到和 DM-RSI-Framework 相同的位置（下面的清单）。已有同名文件时先备份，或者交给 Claude 处理。
2. 打开 Claude Code，把 `rsi_skills/decision_policy/docs/INTEGRATION_PROMPT.md` 里“Prompt”一节整段贴给它，
   并告诉它：“我已经解压了 decision_policy_v5.zip，跳过从 GitHub 复制文件这一步。”
3. 按它的提问确认路径、配置，以及 final-test 的批准。

## 清单

- `pipelines/elliptic_elephant/02b_merge_lora.py`
- `pipelines/elliptic_elephant/03_score_checkpoint.sh`
- `pipelines/elliptic_elephant/04_policy_features.py`
- `pipelines/elliptic_elephant/05_check_merged.py`
- `pipelines/elliptic_elephant/env.example.sh`
- `pipelines/gpu_queue.sh`
- `rsi_skills/decision_policy/SKILL.md`
- `rsi_skills/decision_policy/configs/demo_synthetic.yaml`
- `rsi_skills/decision_policy/configs/elliptic_elephant.yaml`
- `rsi_skills/decision_policy/configs/policies/baseline_f1.yaml`
- `rsi_skills/decision_policy/configs/policies/demo_abstain_hgb_features.yaml`
- `rsi_skills/decision_policy/configs/policies/example_abstain_second_stage.yaml`
- `rsi_skills/decision_policy/configs/policies/example_rolling_platt.yaml`
- `rsi_skills/decision_policy/docs/INTEGRATION_PROMPT.md`
- `rsi_skills/decision_policy/docs/spec.md`
- `rsi_skills/decision_policy/dpolicy/__init__.py`
- `rsi_skills/decision_policy/dpolicy/__main__.py`
- `rsi_skills/decision_policy/dpolicy/bootstrap.py`
- `rsi_skills/decision_policy/dpolicy/calibration.py`
- `rsi_skills/decision_policy/dpolicy/cli.py`
- `rsi_skills/decision_policy/dpolicy/data.py`
- `rsi_skills/decision_policy/dpolicy/decision.py`
- `rsi_skills/decision_policy/dpolicy/diagnose.py`
- `rsi_skills/decision_policy/dpolicy/evolve.py`
- `rsi_skills/decision_policy/dpolicy/metrics.py`
- `rsi_skills/decision_policy/dpolicy/policy.py`
- `rsi_skills/decision_policy/dpolicy/second_stage.py`
- `rsi_skills/decision_policy/dpolicy/synthetic.py`
- `rsi_skills/decision_policy/pyproject.toml`
- `rsi_skills/decision_policy/reference/diagnosis_playbook.md`
- `rsi_skills/decision_policy/reference/evaluation_protocol.md`
- `rsi_skills/decision_policy/reference/policy_space.md`
- `rsi_skills/decision_policy/tests/test_dpolicy.py`
